﻿using System;
using System.Collections.Generic;
namespace Contemporary_Software_Dev_Lab3
{
    public class BoardDirector : IDirector
    {
        private IBuilder _boardBuilder;
        private Printer _printer;

        public BoardDirector(IBuilder boardBuilder)
        {
            this._boardBuilder = boardBuilder;
        }

        public void PlayGame(int depth, Dictionary<string, string> moves)
        {
            _boardBuilder.BuildGameBoard(depth, moves);
            _boardBuilder.PopulateBoards(depth, moves);

            if (_boardBuilder.CheckWin())
            {
                _boardBuilder.SetAllOrderedWinnerLines();
                this._printer = new Printer(this._boardBuilder.GetBoard());
                _printer.PrintWinner();
                _printer.PrintLargeBoard();
                if(depth == 1)
                {
                    _printer.PrintOneNill();
                }
                else if(depth == 2)
                {
                    _printer.PrintSmallBoard();
                    _printer.PrintNumberOfWins();

                }
                
            }
            else
            {
                _printer.PrintTie();
            }

        }
    }
}
