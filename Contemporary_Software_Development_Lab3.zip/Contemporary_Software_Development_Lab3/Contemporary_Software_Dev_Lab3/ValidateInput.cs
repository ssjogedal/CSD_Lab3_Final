﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Contemporary_Software_Dev_Lab3
{
    public class ValidateInput : IValidation
    {

        public ValidateInput(){}

        // Uses first element in input as standard for lenght and loops through the rest
        // comparing lenght.
        public bool ValidateEqualInputLenght(Dictionary<string, string> inputMoves)
        {
            int validLengt = inputMoves.Keys.FirstOrDefault().Length;

            foreach (string move in inputMoves.Keys)
            {
                if (move.Length != validLengt)
                {
                    Console.WriteLine("Invalid input: inconsequent lenght");
                    return false;                    
                }
            }
            return true;
        }


        //If any move is != to any one of the allowed coordonates the method returns false
        public bool ValidateCharacters(string[] inputMoves)
        {

            if (inputMoves[0].Contains("."))
            {
                foreach (string move in inputMoves)
                {
                    string[] splitMove = move.Split(".");
                    foreach (string smove in splitMove)
                    {
                        if (smove != "NW" && smove != "NC" && smove != "NE" && smove != "CW" && smove != "CC"
                            && smove != "CE" && smove != "SW" && smove != "SC" && smove != "SE")
                        {
                            Console.WriteLine("Invalid input: Non existing coordinate");
                            return false;
                        }

                    }
                }
            }
            else
            {
                foreach (string move in inputMoves)
                {
                    if (move != "NW" && move != "NC" && move != "NE" && move != "CW" && move != "CC"
                            && move != "CE" && move != "SW" && move != "SC" && move != "SE")
                    {

                        Console.WriteLine("Invalid input: Non existing coordinate");
                        return false;

                    }

                }
            }
            return true;
    
        }
       
    }

}







