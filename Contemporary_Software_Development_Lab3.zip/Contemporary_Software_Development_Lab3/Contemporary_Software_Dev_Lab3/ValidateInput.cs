﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Contemporary_Software_Dev_Lab3
{
    public class ValidateInput
    {

        public ValidateInput(){}

        // Uses first element in input as standard for lenght and loops through the rest
        // comparing lenght.
        public bool ValidateEqualInputLenght(Dictionary<string, string> inputMoves)
        {
            int validLengt = inputMoves.Keys.FirstOrDefault().Length;

            foreach (string move in inputMoves.Keys)
            {
                if (move.Length != validLengt)
                {
                    Console.WriteLine("Invalid input: inconsequent lenght");
                    return false;                    
                }
            }
            return true;
        }


        //The thought is that this will only return true if the input moves are one of the coordinates in the if-statement
        // However not working 100% as of now
        public bool ValidateCharachters(Dictionary<string, string> inputMoves)
        {

            if (inputMoves.Keys.First().Contains("."))
            {
                foreach (string move in inputMoves.Keys)
                {
                    string[] splitMove = move.Split(".");
                    foreach (string smove in splitMove)
                    {
                        if (smove == "NW" || smove == "NC" || smove == "NE" || smove == "CW" || smove == "CC"
                            || smove == "CE" || smove == "SW" || smove == "SC" || smove == "SE")
                        {

                            return true;
                            
                        }
                        Console.WriteLine("Invalid input");
                        return false;
                    }
                }

                foreach (string move in inputMoves.Keys)
                {
                    if (move == "NW" || move == "NC" || move == "NE" || move == "CW" || move == "CC"
                            || move == "CE" || move == "SW" || move == "SC" || move == "SE")
                    {

                        return true;

                    }

                    Console.WriteLine("Invalid input");
                    return false;

                }
                
            }
            return true;
        }

    }
}






