﻿using System.Collections.Generic;
using System.Linq;

namespace Contemporary_Software_Dev_Lab3
{
    class SuperBoard : IBoard
    {

        private Dictionary<string, IBoard> _boards = new Dictionary<string, IBoard>();
        private Dictionary<string, string> _boardWinners = new Dictionary<string, string>();
        private List<string> _boardsWinnerLines = new List<string>();
        private string _position;
        private string _winner;
        private List<string> _winnerLine = new List<string>();



        public SuperBoard(){}

        public SuperBoard(string position)
        {
            this._position = position;
        }


        public void SetPosition(string position)
        {
            this._position = position;
        }

        //Looks at the board winner to see if enogh small board have been won to win the main board
        // Add winner and winner line if found
        public bool IsLine(string pos1, string pos2, string pos3)
        {
            
            if (this._boardWinners.ContainsKey(pos1) && this._boardWinners.ContainsKey(pos2) && this._boardWinners.ContainsKey(pos3))
            {
                string player = this._boardWinners[pos1];

                if (this._boardWinners[pos2] == player && this._boardWinners[pos3] == player)
                {
                    this._winner = player;
                    this._winnerLine.Add(pos1);
                    this._winnerLine.Add(pos2);
                    this._winnerLine.Add(pos3);
                    return true;
                }
                return false;
            }
            return false;
        }

        // Loops throuh all the boards small boards checking for win.
        // Winner gets put on the list and passed to IsLine()
        public bool CheckWin(string[] winnerPatterns)
        {

            foreach (IBoard board in _boards.Values)
            {
                if (board.CheckWin(winnerPatterns))
                {
                    _boardWinners.TryAdd(board.GetPosition(), board.GetWinner());
                }
            }

            foreach (string pattern in winnerPatterns)
            {
                string[] patternSplit = pattern.Split(",");

                if(IsLine(patternSplit[0], patternSplit[1], patternSplit[2]))
                {
                    return true;
                }
            }
            return false;

        }

        // Retrieve small boards winner lines and adds the main board kooedinate
        // Backtracking so get the full coordinate
        public string GetSmallBoardsUnorderedWinnerlines()
        {
            string winningSmallBoards = "";

            foreach (string position in _winnerLine)
            {
                List<string> smallBoardWinnerLine = _boards[position].GetWinnerLine();

                string firstWinnerLine = $"{position}.{smallBoardWinnerLine[0]}";
                string secondWinnerLine = $"{position}.{smallBoardWinnerLine[1]}";
                string thirdWinnerLine = $"{position}.{smallBoardWinnerLine[2]}";

                winningSmallBoards += $"{firstWinnerLine},{secondWinnerLine},{thirdWinnerLine},";
            }

            return winningSmallBoards.Substring(0, winningSmallBoards.Length - 1);
        }

        // Sets all winner lines, small boards and main, in the order they were played.
        public void SetAllOrderedWinnerLines(string unalteredInputMoves)
        {
            List<string> winnerLines = new List<string>();
            List<string> inputMoves = new List<string>();

            string[] unorderedWinnerLines = GetSmallBoardsUnorderedWinnerlines().Split(",");
            string[] inputMovesSplit = unalteredInputMoves.Split(",");

            foreach (string move in unorderedWinnerLines)
            {
                winnerLines.Add(move);
            }

            foreach (string move in inputMovesSplit)
            {
                inputMoves.Add(move);
            }

            List<string> orderedBoardsWinnerLines = inputMoves.Intersect(winnerLines).ToList();
            List<string> orderedBoardsWinnerLinesMainCoordinateOnly = new List<string>();

            foreach (string move in orderedBoardsWinnerLines)
            {
                orderedBoardsWinnerLinesMainCoordinateOnly.Add(move.Split(".")[0]);
            }

            List<string> unorderedMainBoardWinnerLine = new List<string>();

            foreach (string move in GetWinnerLine())
            {
                unorderedMainBoardWinnerLine.Add(move);
            }

            List<string> orderedMainBoardWinnerLine = orderedBoardsWinnerLinesMainCoordinateOnly.Intersect(unorderedMainBoardWinnerLine).ToList();

            this._boardsWinnerLines = orderedBoardsWinnerLines;
            this._winnerLine = orderedMainBoardWinnerLine;

        }

        public void SetWinners(IBoard board)
        {
           _boardWinners.TryAdd(board.GetPosition(), board.GetWinner());  
        }

        public string GetWinner()
        {
            return _winner;
        }

        public List<string> GetWinnerLine()
        {
            return _winnerLine;
        }

        public Dictionary<string, string> GetBoardWinners()
        {
            return _boardWinners;
        }

        public List<string> GetBoardsWinnerLines()
        {
            return _boardsWinnerLines;
        }

        public string GetPosition()
        {
            return _position;
        }

        
        public void AddBoard(IBoard board)
        {
            this._boards.Add(board.GetPosition(), board);
        }

        public Dictionary<string, IBoard> GetBoards()
        {
            return _boards;
        }

        public void GenerateBoard(Dictionary<string, string> moves)
        {
            throw new System.NotImplementedException();
        }

        public void AddMoves(string move, string player)
        {
            throw new System.NotImplementedException();
        }
    }
}



