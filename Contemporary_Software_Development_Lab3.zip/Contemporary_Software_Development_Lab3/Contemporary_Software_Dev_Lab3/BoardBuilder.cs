﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Contemporary_Software_Dev_Lab3
{
    public class BoardBuilder : IBuilder
    {

        private IBoard _board;
        private string _unalteredInputMoves;
        private string[] squarePositions = new string[] { "NW", "NC", "NE", "CW", "CC", "CE", "SW", "SC", "SE" };
        private string[] _winnerPatterns = new string[] { "NW,CW,SW", "NC,CC,SC", "NE,CE,SE",
                                                          "NW,NC,NE", "CW,CC,CE", "SW,SC,SE",
                                                          "NW,CC,SE", "SW,CC,NE" };

        public BoardBuilder(string unalteredInputMoves)
        {
            Reset();
            this._unalteredInputMoves = unalteredInputMoves;
        }

        public void Reset()
        {
            this._board = new SuperBoard("Base Board");
        }

        public void SetPosition(string position)
        {
            _board.SetPosition(position);
        }

        // Changes the bord to a "small" board in case depth == 1
        // For depth == 2 small boards are added to board dictionary
        public void BuildGameBoard(int depth, Dictionary<string, string> moves)
        {
            
            if (depth == 1)
            {
                this._board = new Board("Base Board");
                
            }
            
            else if (depth == 2)
            {
                for (int i = 0; i < squarePositions.Length; i++)
                {
                    IBoard board = new Board(squarePositions[i]);
                    this._board.AddBoard(board);
                } 
            }
            
        }

        // Adding the moves 
        public void PopulateBoards(int depth, Dictionary<string, string> moves)
        {
            if (depth == 1)
            {
                this._board.GenerateBoard(moves);
            }
            else
            {
                foreach(string key in moves.Keys)
                {
                    string boardPosition = key.Split(".")[0];
                    string move = key.Split(".")[1];
                    string player = moves[key];

                    this._board.GetBoards()[boardPosition].AddMoves(move, player);
                }
                 
            }
            
        }

        public IBoard GetBoard()
        {
            return _board;
        }

        public Dictionary<string, string> GetBoardWinners()
        {
           return this._board.GetBoardWinners();
        }

        public void SetAllOrderedWinnerLines()
        {
            this._board.SetAllOrderedWinnerLines(_unalteredInputMoves);
        }

        public bool CheckWin()
        {
            if (this._board.CheckWin(_winnerPatterns))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
