﻿using System.Collections.Generic;
using System.Linq;

namespace Contemporary_Software_Dev_Lab3
{
    class Board : IBoard
    {

        public Dictionary<string, string> _squares = new Dictionary<string, string>();
        List<string> _winnerLine = new List<string>();
        public string _position;
        public string _winner;
        

        public Board(){}

        public Board(string position)
        {
            this._position = position;
        }

        public void SetPosition(string position)
        {
            this._position = position;
        }

        public void GenerateBoard(Dictionary<string, string> moves)
        {
            this._squares = moves;
        }

        public void AddMoves(string move, string player)
        {
            _squares.TryAdd(move, player);
        }

        public Dictionary<IBoard, string> GetBoards()
        {
            Dictionary<IBoard, string> thisBoard = new Dictionary<IBoard, string>();
            thisBoard.Add(this, _winner);

            return thisBoard;   
        }

        // Checks for winning line. If found, adds player and winner line to this board
        public bool IsLine(string pos1, string pos2, string pos3)
        {
            if (this._squares.ContainsKey(pos1) && this._squares.ContainsKey(pos2) && this._squares.ContainsKey(pos3))
            {
                
                string player = this._squares[pos1];

                if (this._squares[pos2] == player && this._squares[pos3] == player)
                {

                    this._winner = player;
                    this._winnerLine.Add(pos1);
                    this._winnerLine.Add(pos2);
                    this._winnerLine.Add(pos3);
                    return true;
                }
                return false;
            }
            return false;
        }

        // Loops through all winner patterns calling on IsLine
        public bool CheckWin(string[] winnerPatterns)
        {
            foreach (string pattern in winnerPatterns)
            {
                string[] patternSplit = pattern.Split(",");
                if (IsLine(patternSplit[0], patternSplit[1], patternSplit[2]))
                {
                    return true;
                }
            }
            return false;
        }

        // Retrives the winner lines and sort them in the order they were played
        public void SetAllOrderedWinnerLines(string unalteredInputMoves)
        {
            List<string> inputMoves = new List<string>();

            string[] inputMovesSplit = unalteredInputMoves.Split(",");

            foreach (string move in inputMovesSplit)
            {
                inputMoves.Add(move);
            }

            _winnerLine = inputMoves.Intersect(_winnerLine).ToList();
            
        }

        public string GetWinner()
        {
            return _winner;
        }

        public List<string> GetWinnerLine()
        {
            return _winnerLine;
        }

        public string GetPosition()
        {
            return _position;
        }

        public void AddBoard(IBoard board)
        {
            throw new System.NotImplementedException();
        }

        Dictionary<string, IBoard> IBoard.GetBoards()
        {
            throw new System.NotImplementedException();
        }

        public void SetWinners(IBoard board)
        {
            throw new System.NotImplementedException();
        }

        public string GetSmallBoardsUnorderedWinnerlines()
        {
            throw new System.NotImplementedException();
        }

        public List<string> GetBoardsWinnerLines()
        {
            throw new System.NotImplementedException();
        }

        public Dictionary<string, string> GetBoardWinners()
        {
            throw new System.NotImplementedException();
        }
    }   
}



