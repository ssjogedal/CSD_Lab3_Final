﻿using System;
using System.Collections.Generic;
namespace Contemporary_Software_Dev_Lab3
{
    public interface IValidation
    {
        public bool ValidateEqualInputLenght(Dictionary<string, string> inputMoves);
        public bool ValidateCharacters(string[] inputMoves);

    }
}
