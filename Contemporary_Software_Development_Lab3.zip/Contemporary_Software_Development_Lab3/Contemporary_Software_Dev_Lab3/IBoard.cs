﻿using System.Collections.Generic;


namespace Contemporary_Software_Dev_Lab3
{
    public interface IBoard
    {
        public void GenerateBoard(Dictionary<string, string> moves);
        public void AddBoard(IBoard board);
        public void SetPosition(string position);
        public Dictionary<string, IBoard> GetBoards();
        public bool IsLine(string pos1, string pos2, string pos3);
        public string GetWinner();
        public List<string> GetWinnerLine();
        public string GetPosition();
        public void AddMoves(string move, string player);
        public void SetWinners(IBoard board);
        public bool CheckWin(string[] winnerPatterns);
        public string GetSmallBoardsUnorderedWinnerlines();
        public void SetAllOrderedWinnerLines(string unalteredInputMoves);
        public List<string> GetBoardsWinnerLines();
        public Dictionary<string, string> GetBoardWinners();

    }
}


