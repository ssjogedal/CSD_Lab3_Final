﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Contemporary_Software_Dev_Lab3
{
    public class Printer
    {
        IBoard _board;

        public Printer(IBoard board)
        {
            this._board = board;
        }

        public void PrintWinner()
        {
            Console.WriteLine($"Winner: {this._board.GetWinner()}");
        }

        public string PrintLargeBoard()
        {
            string message = "";
            foreach(string move in this._board.GetWinnerLine())
            {
                message += $"{move},";
            }

            Console.WriteLine(message.Substring(0,message.Length-1));
            return message.Substring(0, message.Length - 1);
        }

        public string PrintSmallBoard()
        {
            string message = "";
            foreach(string move in this._board.GetBoardsWinnerLines())
            {
                message += $"{move},";
            }

            Console.WriteLine(message.Substring(0, message.Length - 1));
            return message.Substring(0, message.Length - 1);
        }

        //Retrieves small board winners and count their wins. Also retrives winner of main board for score keeping.
        public string PrintNumberOfWins()
        {
            int xCountSmall = this._board.GetBoardWinners().Values.Where((winner) => winner == "PlayerX").Count();
            int oCountSmall = this._board.GetBoardWinners().Values.Where((winner) => winner == "PlayerO").Count();

            int xCountLarge = 0;
            int oCountLarge = 0;

            if (this._board.GetWinner() == "PlayerX")
            {
                xCountLarge = 1;

            }
            else if(this._board.GetWinner() == "PlayerO")
            {
                oCountLarge = 1;
            }

            Console.WriteLine($"{xCountSmall}.{oCountSmall},{xCountLarge}.{oCountLarge}");
            return $"{xCountSmall}.{oCountSmall},{xCountLarge}.{oCountLarge}";
        }

        // Print the 1-0 score when 1-depth boards
        public void PrintOneNill()
        {
            int xCount = 0;
            int oCount = 0;

            if (this._board.GetWinner() == "PlayerX")
            {
                xCount = 1;

            }
            else if (this._board.GetWinner() == "PlayerO")
            {
                oCount = 1;
            }

            Console.WriteLine($"{xCount}.{oCount}");
        }

        public void PrintTie()
        {
            Console.WriteLine("Tie!");
        }
    }
}
