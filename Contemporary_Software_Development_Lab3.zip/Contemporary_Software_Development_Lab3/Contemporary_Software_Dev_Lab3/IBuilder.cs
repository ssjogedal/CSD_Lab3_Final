﻿using System;
using System.Collections.Generic;
namespace Contemporary_Software_Dev_Lab3
{
    public interface IBuilder
    {
        
        public void Reset();
        public void BuildGameBoard(int depth, Dictionary<string, string> moves);
        public void SetPosition(string position);
        public void PopulateBoards(int depth, Dictionary<string, string> moves);
        public bool CheckWin();
        public void SetAllOrderedWinnerLines();
        public IBoard GetBoard();
        public Dictionary<string, string> GetBoardWinners();

    }
}
