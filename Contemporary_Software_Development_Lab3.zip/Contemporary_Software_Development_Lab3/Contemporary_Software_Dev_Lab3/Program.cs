﻿using System;
using System.Collections.Generic;
namespace Contemporary_Software_Dev_Lab3
{
    class Program
    {
        static void Main(string[] args)
        {

            //Adding moves and corresponding players to dictionary wich wont allow duplicate moves
            Dictionary<string, string> moves = new Dictionary<string, string>();

            string[] splitMoves = args[0].Trim().Split(",");
            int depth = 1;

            if (splitMoves[0].Length > 2)
            {
                depth = splitMoves[0].Split(".").Length;
            }

            int playCount = 0;
            foreach (string move in splitMoves)
            {
                if (move != "")
                {
                    if (playCount % 2 == 0)
                    {
                        if(moves.TryAdd(move, "PlayerX"))
                        {
                            //Increase playCount only if succesfully added move
                            playCount++; 
                        }
                        else
                        {
                            Console.WriteLine("Invalid move for PlayerX: Duplicate move");
                        }
                    }
                    else
                    {
                        if(moves.TryAdd(move, "PlayerO"))
                        {
                            playCount++;
                        }
                        else
                        {
                            Console.WriteLine("Invalid move for PlayerO: Duplicate move");
                        }

                    }
                }

            }

            //If input passes the validation, create a builder with the input, and a director with the builder, director initiates the game. 
            ValidateInput validator = new ValidateInput();
            if (validator.ValidateEqualInputLenght(moves) &&
            validator.ValidateCharacters(splitMoves))
            {
                IBuilder boardBuilder = new BoardBuilder(args[0]);
                IDirector boardDirector = new BoardDirector(boardBuilder);

                boardDirector.PlayGame(depth, moves);
            }

            
            










        }
    }

}


