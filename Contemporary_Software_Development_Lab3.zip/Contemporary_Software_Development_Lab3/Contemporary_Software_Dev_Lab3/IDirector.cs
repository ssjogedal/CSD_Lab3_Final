﻿using System;
using System.Collections.Generic;
namespace Contemporary_Software_Dev_Lab3
{
    public interface IDirector
    {
        public void PlayGame(int depth, Dictionary<string, string> moves);
    }
}
