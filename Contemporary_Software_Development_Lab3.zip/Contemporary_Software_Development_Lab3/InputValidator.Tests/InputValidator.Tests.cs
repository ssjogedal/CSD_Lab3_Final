using Xunit;
using System.Collections.Generic;
using System;
using Contemporary_Software_Dev_Lab3;

namespace InputValidator.Tests
{
    public class InputValidator
    {
        
        [Fact]
        public void ValidateInvalidInpu()
        {
            
            //index 2 has depth = 3 
            string testInput = "NW.CC,NC.CC,NW.NW,NE.CC,NW.SE,CE.CC,CW.CC,SE.CC,CW.NW,CC.CC,CW.SE,CC.NW,CC.SE,CE.NW,SW.CC,CE.SE,SW.NW,SE.SE,SW.SE";
            string expectedLarge = "NW,CW,SW";
            string expectedSmall = "NW.CC,NW.NW,NW.SE,CW.CC,CW.NW,CW.SE,SW.CC,SW.NW,SW.SE";
            string expectedWins = "3.1,1.0";
            Dictionary<string, string> testMoves = new Dictionary<string, string>();

            string[] splitMoves = testInput.Split(",");
            int depth = 1;

            if (splitMoves[0].Length > 2)
            {
                depth = splitMoves[0].Split(".").Length;
            }

            int playCount = 0;
            foreach (string move in splitMoves)
            {
                if (move != "")
                {
                    if (playCount % 2 == 0)
                    {
                        if (testMoves.TryAdd(move, "PlayerX"))
                        {
                            playCount++;
                        }
                        else
                        {
                            Console.WriteLine("Invalid move for PlayerX: Duplicate move");
                        }
                    }
                    else
                    {
                        if (testMoves.TryAdd(move, "PlayerO"))
                        {
                            playCount++;
                        }
                        else
                        {
                            Console.WriteLine("Invalid move for PlayerO: Duplicate move");
                        }

                    }
                }

            }

            IBuilder boardBuilder = new BoardBuilder(testInput);
            IDirector boardDirector = new BoardDirector(boardBuilder);

            boardDirector.PlayGame(depth, testMoves);

            Printer printer = new Printer(boardBuilder.GetBoard());
            string largeBoardResult = printer.PrintLargeBoard();


            Assert.Equal(printer.PrintLargeBoard(), expectedLarge);
            Assert.Equal(printer.PrintSmallBoard(), expectedSmall);
            Assert.Equal(printer.PrintNumberOfWins(), expectedWins);
            
        }

        
    }
}
